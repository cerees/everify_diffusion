% readme

to compile use:

mex shp_read.c shapelib.c

which creates shp_read.dll

mex dbf_read.c shapelib.c

which creates dbf_read.dll

-----------------------------
linux_2.6 zip/rar file
contains source and executable for linux

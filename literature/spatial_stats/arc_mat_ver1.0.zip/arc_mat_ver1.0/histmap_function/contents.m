%      am_histcmap : sets the colormap for the histmap figure
%    am_histlegend : compute legend figure for histmap
%       am_histmap : uses rubber band rectangle to select a sub-region of the histmap
%      am_histncat : sets the # of histogram bars in histmap
%      am_histquit : closes histmap figure windows
%  am_histvariable : sets the variable for use by histmap
%      arc_histmap : produce a map with histogram legend using ArcView shape files
%     arc_histmapd : An example of using arc_histmap() 
%    arc_histmapd2 : An example of using arc_histmap() 
%    arc_histmapd3 : An example of using arc_histmap() 
%    arc_histmapd4 : An example of using arc_histmap() 
%    arc_histmapd5 : An example of using arc_histmap() 
%    arc_histmapd6 : An example of using arc_histmap() 
%    arc_histmapd7 : An example of using arc_histmap() 
%    arc_histmapd8 : An example of using arc_histmap() 
%    arc_histmapd9 : An example of using arc_histmap() 
%        make_html : makes HTML verion of contents.m files for the Econometrics Toolbox
